README



Purpose:
	
	1. Design a single-threaded and a multiple-threaded algorithms to compute the product of two matrices, the size of each is 10000 X 10000
	2. Compare the elapsed time between the two algorithms


Methods:
	1. Single-threaded computation 
	2. Multiple-threaded computation



Algorithm:
	Single-threaded program:
    
	1. Generate two matrices using random numbers in the range of 1 to 2000   
	2. Multiply two matrices  




	Multi-threaded program:
    
	1. Generate two matrices using random numbers in the range of 1 to 2000   
	2. Divide the task into 25 subtasks 
	3. Generate 25 threads, and assign each thread to one subtask 
	4. Multiply two matrices by multiple threads


Note:
	1. Time delay: 
	   for the convience of observation, a 10 microsecond delay is added after the computation of each element in the reuslt matrix
	2. Formula for matrix product:
	   C[i, j] = sum(A[i, k]*B[k,j]) for all k from 1 to 10000

Compile:
	multi-threaded:  gcc -pthread -o prog1 -prog1.c
	single-threaded: gcc -o prog2 -prog2.c

Execute:
	Create report.sh file to execute prog1 and prog2 respectively and print the date at the begining and end of execution.

Script:
	Program 1 starts
	
	Tue Oct  9 14:44:42 CDT 2018
	
	Tue Oct  9 15:00:08 CDT 2018
	
	Program 1 ends
	
	Program 2 starts
	
	Tue Oct  9 15:00:08 CDT 2018
	
	Tue Oct  9 20:04:04 CDT 2018
	
	Program2 ends




Summary: 
	Total time elapsed for single-threaded program is 5 hours 3 mins and 56s. 
	Total time elapsed for multi-threaded program is 15 mins and 26s
	Based on the reuslt, we draw the conclusion that the run time for multithreaded programming is faster than the run time for singlethreaded programming
