echo 'Program 1 starts'
date
./prog1
date
echo 'Program 1 ends'

echo 'Program 2 starts'
date
./prog2
date
echo 'Program2 ends'

