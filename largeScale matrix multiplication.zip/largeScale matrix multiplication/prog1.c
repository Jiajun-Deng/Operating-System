/*
Date:9-20-2018
Revised: 9-21-2018 add threads
         9-22-2018 add time delay
Unresolved: script sovled on 10-2
Description:
            1. Generate two matrices,Using random numbers.
            2. Multiply two matrices.
            3. Display matrix//deleted
            4. Generate 25 threads, assign the multiplication task for 25 threads.
            5. Delay of 10 microseconds between two elements' computation in multiplication process.
            6. Semaphore needed to protect the shared variable, which is used for the specific rows of multiplication.//Deleted, semaphore will increased the time consumption.

Portability:
            1. The function to multiply two matrices. INPUT AND RETURN void
            2. Define MAX, set value be large enough for 10000*10000
            3. Add the header file, <pthread.h>
            4. While compling, link the library -phtread.
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#define MAX 10000 //size of the matrices are MAX*MAX

//global variables
    int matA[MAX][MAX];
    int matB[MAX][MAX];
    int matC[MAX][MAX];
    int Thread_Num = 25;  //total number of threads
    int a = 1,b = 2000; //the range of random numbers

//*************************************************
//Function that generates and displays two matrices 
//Input args: void *arg
//Return NULL
//*************************************************

void generate_matrix( )
{
int i,j;
for(i = 0;i < MAX;i++)
{  for(j = 0;j < MAX ;j++)
  {
		matA[i][j] = rand()%(b-a+1)+a;
    matB[i][j] = rand()%(b-a+1)+a;
   }
}		
}

//************************************
//Function for printing a matrix,and write it into a file
//Input args:  int matrix[MAX][MAX]
//Return value: void
//************************************
void display_matrix(int matrix[MAX][MAX])
{
    int i,j;

    for(i = 0;i < MAX;i++)
    {
        for(j = 0;j < MAX ;j++)
	      {
	   		    printf("%d ",matrix[i][j]);
	      }
		printf("\n");
    }
}

//************************************
//Function that will multiply two matrices
//Input args:  void* arg, so any type of arguments can be passed into.
//Return value: void*
//************************************

void* matrix_multi(void* arg)
{

    int i,j,k,n;
    int *p = (int*)arg;
    int id = *p;    
    
      for(i = id*MAX/Thread_Num; i < (id+1)*MAX/Thread_Num; i++)
      {
//        printf("Pthread no %d is computing\n", myNum );//print out which thread is executing.
        for(j = 0; j < MAX; j++)
            {
            for(k = 0; k < MAX ; k++)
            {
                matC[i][j] += matA[i][k]*matB[k][j];  //Based on the definition of Matrices multiplication.
                }
                usleep(10);
                }
      }
}

int main(int argc, char *argv[])
{ 
	int i,j,k;
  int tNum[Thread_Num];
  pthread_t tid[Thread_Num];
  
  generate_matrix();//Generate two matrices matA and matB
  
for(i=0; i< Thread_Num; i++)
{
    tNum[i] = i;  //record the No. of thread
    pthread_create(&tid[i], NULL, matrix_multi, &tNum[i]);  
}
for(i=0; i< Thread_Num; i++)
pthread_join(tid[i],NULL);
   
	return 0;
}
