/*
Date:9-20-2018
Revised: 9-21-2018
Author: Jiajun Deng
Description:
            1.Generate two matrices,Using random numbers.
            2.Multiply two matrices.
            3.After computing each element of the new matrix, delay 1 microseconds.
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define MAX 10000 //size of the matrices are MAX*MAX

//global variables
    int matA[MAX][MAX];
    int matB[MAX][MAX];
    int matC[MAX][MAX];
    int a = 1,b = 2000;

//*************************************************
//Function that generates two matrices using random
//numbers in range[a,b]
//Input args: void *arg
//Return NULL
//*************************************************

void generate_matrix( )
{
int i,j;
for(i = 0;i < MAX;i++)
{  for(j = 0;j < MAX ;j++)
  {
		matA[i][j] = rand()%(b-a+1)+a;
    matB[i][j] = rand()%(b-a+1)+a;
   }
}		
}

//************************************
//Function for printing a matrix
//Input args:  int matrix[MAX][MAX]
//Return value: void*
//************************************
void display_matrix(int matrix[MAX][MAX])
{
    int i,j;
    for(i = 0;i < MAX;i++)
    {
        for(j = 0;j < MAX ;j++)
	      {
	   		    printf("%d ",matrix[i][j]);

	      }
		printf("\n");
    }
}

//************************************
//Function that will multiply two matrices
//Input args:  void
//Return value: void
//************************************

void matrix_multi( )
{
    int i,j,k,n;
       for(i = 0; i < MAX; i++)
        for(j = 0; j < MAX; j++)
          {  for(k = 0; k < MAX ; k++)
            {
                matC[i][j] += matA[i][k]*matB[k][j];  //Based on the definition of Matrices multiplication.
                }
               usleep(10);
        }
}


int main(int argc, char *argv[])
{ 
	int i,j,k;
  
  generate_matrix();
  
  matrix_multi();

	return 0;
}
